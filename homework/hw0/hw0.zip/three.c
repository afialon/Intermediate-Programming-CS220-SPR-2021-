//Alex Fialon
//afialon1
#include <stdio.h>

int main() {

  //display a greeting
  printf("The first prize goes to Sophi.\n");
  return 0;
}



