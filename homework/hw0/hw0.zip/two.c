//Alex Fialon
//afialon1
#include <stdio.h>

int main() {

  //display a greeting
  printf("The second prize goes to Brandon.\n");
  return 0;
}

