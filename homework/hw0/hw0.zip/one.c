//Alex Fialon
//afialon1

#include <stdio.h>

int main() {

  //display a greeting
  printf("The third prize goes to Emily.\n");
  return 0;
}
